﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CriminalDetectingSystem
{
    public class Publisher
    {
        public Publisher()
        {

        }

        public event find CriminalSeen;
        protected virtual void OnCriminalSeen(CriminalType e)
        {
            find handler = CriminalSeen;
            if (handler != null)
            {
                handler?.Invoke(this, e);
            }

        }

        public void OnCriminalSeen()
        {
            Console.Write("Press 'T' for Terrorist");
            Console.Write("\nPress 'H' for Thieves");
            Console.Write("\nEnter Choice: ");
            char c = Console.ReadKey().KeyChar;
            if (c == 'T')
                CriminalSeen(this, new CriminalType("Terrorist"));
            if (c == 'H')
                CriminalSeen(this, new CriminalType("Thieve"));
        }

    }
}
