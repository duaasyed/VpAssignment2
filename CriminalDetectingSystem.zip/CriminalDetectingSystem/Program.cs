﻿using System;

namespace CriminalDetectingSystem
{
    public delegate void find(object source, CriminalType e);
    class Program
    {

        static void Main()
        {

            Console.WriteLine(" \n\t\t CRIMINAL DETECTING SYSTEM \t\t");
            Console.WriteLine(" \t\t SYEDA DUAA FATIMA BUKHARI \t\t");
            Console.WriteLine(" \t\t       01-131182-035 \t\t");
            Publisher people = new Publisher();
            Subscriber police = new Subscriber();
            people.CriminalSeen += new find(police.onCriminalSeen);
            int ch = 1;
            while (ch != 0)
            {
                people.OnCriminalSeen();
                Console.Write("\n\n Press (1) to continue...");
                Console.Write("\n Press (0) to Exit");
                Console.Write("\n Enter Choice: ");
                ch = int.Parse(Console.ReadLine());
                Console.Write(" \n ");
            }

            Console.WriteLine("\nThief: " + police.Thieves);
            Console.WriteLine("Terrorist: " + police.Terrorists);



        }
    }
}

