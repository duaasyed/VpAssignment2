﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CriminalDetectingSystem
{
    class Subscriber
    {
        private int thieves, terrorists;
        public Subscriber()
        {
            this.Thieves = this.Terrorists = 0;
        }
        public int Thieves
        {
            get
            {
                return thieves;
            }
            set
            {
                thieves = value;
            }
        }
        public int Terrorists
        {
            get
            {
                return terrorists;
            }

            set
            {
                terrorists = value;
            }
        }

        public void TheifCount()
        {
            this.Thieves++;
        }
        public void TerroristCount()
        {
            this.Terrorists++;
        }
        public void onCriminalSeen(object source, CriminalType t)
        {
            if (t.Type == "Thief")
                this.TheifCount();
            if (t.Type == "Terrorist")
                this.TerroristCount();
        }
    }
}
