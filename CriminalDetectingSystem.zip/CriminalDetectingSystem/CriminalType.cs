﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CriminalDetectingSystem
{
    public class CriminalType : EventArgs
    {
        public string type;
        public CriminalType(string criminal)
        {
            type = criminal;
        }
        public string Type
        {
            get
            {
                return type;
            }
            set
            {
                type = value;
            }
        }
    }
}
